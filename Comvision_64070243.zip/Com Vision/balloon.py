import cv2
import numpy as np
img = cv2.imread('balloons.jpeg')
balloon = img[120:260, 360:480]
img2 = img.copy()
img2[95:95+140, 230:350] = balloon

img2[110:250, 500:620] = balloon
while(1):
    cv2.imshow('image',img2)
    k = cv2.waitKey(1) & 0xFF
    if k == 27: # key ESC
        break
cv2.destroyAllWindows()