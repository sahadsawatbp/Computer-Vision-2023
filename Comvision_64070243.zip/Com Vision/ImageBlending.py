import cv2
import numpy as np
from matplotlib import pyplot as plt
from math import ceil
import os
path = "Image/"
images = os.listdir(path)
length = len(images)
i = 1
width = 600
height = 400
dim = [width,height]
screen = np.zeros((height,width,3), np.uint8)
highest = 1.0
lowest = 0.0
img = cv2.imread(path + images[i])
img = cv2.resize(img,dim,interpolation=cv2.INTER_CUBIC)
while(True):
    if(ceil(highest) == 0):
        highest = 1.0
        lowest = 0.0
        i = (i+1) % length
        img = cv2.imread(path + images[i])
        img = cv2.resize(img,dim,interpolation=cv2.INTER_CUBIC)

    highest -= 0.008
    lowest += 0.008
    screen = cv2.addWeighted(screen,highest,img,lowest,0)
    cv2.imshow('ImageSlideShow',screen)
    key = cv2.waitKey(1) & 0xff
    if key==ord('x'):
        break
cv2.destroyAllWindows()
